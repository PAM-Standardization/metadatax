from typing import Optional

from django import forms
from django.contrib.contenttypes.models import ContentType
from django.forms.utils import ErrorList
from django_extension.forms.fields import ContentTypeAutocompleteSelectField

from metadatax.common.models import Person, Team, Institution
from metadatax.equipment.models import Equipment


class EquipmentForm(forms.ModelForm):
    # Additional typing
    instance: Optional[Equipment]
    owner = forms.CharField()  # Temporary placeholder

    class Meta:
        model = Equipment
        exclude = ("owner_type", "owner_id")

    def __init__(self, data=None, files=None, auto_id='id_%s', prefix=None, initial=None, error_class=ErrorList,
                 label_suffix=None, empty_permitted=False, instance=None, use_required_attribute=None, renderer=None):
        super().__init__(data, files, auto_id, prefix, initial, error_class, label_suffix, empty_permitted, instance,
                         use_required_attribute, renderer)
        # Only execute query when form is instantiated
        self.fields['owner'] = ContentTypeAutocompleteSelectField(
            models=[Person, Team, Institution],
            initial=instance.owner if instance is not None else None,
        )

    def save(self, commit=True):
        self.instance.owner_type = ContentType.objects.get_for_model(self.cleaned_data['owner'])
        self.instance.owner_id = self.cleaned_data['owner'].pk

        return super().save(commit)
