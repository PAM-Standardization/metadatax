from .tagged_item import TaggedItemForm
from .contact_relation import ContactRelationForm
