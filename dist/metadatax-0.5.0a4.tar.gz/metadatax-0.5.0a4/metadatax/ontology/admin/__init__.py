"""Ontology admin"""

from .label import LabelAdmin
from .sound import SoundAdmin
from .source import SourceAdmin
