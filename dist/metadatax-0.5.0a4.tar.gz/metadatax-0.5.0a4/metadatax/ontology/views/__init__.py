"""Ontology views"""

from .label import LabelViewSet
from .sound import SoundViewSet
from .source import SourceViewSet
