from .audio_properties import AudioProperties
from .detection_properties import DetectionProperties
