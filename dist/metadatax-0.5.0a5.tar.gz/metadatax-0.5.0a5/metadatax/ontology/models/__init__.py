"""Ontology models"""
from .__enums__ import *
from .label import Label
from .sound import Sound
from .source import Source
