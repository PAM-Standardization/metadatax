from django.apps import AppConfig


class OntologyConfig(AppConfig):
    default_auto_field = "django.db.models.BigAutoField"
    name = "metadatax.ontology"
    verbose_name = "Metadatax Ontology"
