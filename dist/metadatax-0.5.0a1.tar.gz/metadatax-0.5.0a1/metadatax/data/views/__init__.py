from .audio_file import AudioFileViewSet
from .detection_file import DetectionFileViewSet
from .file import FileViewSet
