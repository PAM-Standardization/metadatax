import graphene
from django_extension.schema.types import ExtendedNode

from metadatax.bibliography.models import Poster
from metadatax.bibliography.schema.enums import BibliographyStatusEnum, BibliographyTypeEnum
from metadatax.common.schema.nodes.tag import TagNode


class PosterNode(ExtendedNode):
    type = graphene.NonNull(BibliographyTypeEnum)
    status = graphene.NonNull(BibliographyStatusEnum)

    tags = graphene.List(TagNode)

    conference_name = graphene.String(required=True)
    conference_location = graphene.String(required=True)

    class Meta:
        model = Poster
        exclude = (
            "journal",
            "volumes",
            "pages_from",
            "pages_to",
            "issue_nb",
            "article_nb",
            "publication_place",
            "repository_url",
        )
        filter_fields = {
            "id": ["exact", "in"],
            "type": ["exact", "in"],
            "title": ["exact", "icontains"],
            "conference_name": ["exact", "icontains"],
            "conference_location": ["exact", "icontains"],
            "doi": ["exact"],
            "status": ["exact"],
            "publication_date": ["exact", "lt", "lte", "gt", "gte"],
        }
