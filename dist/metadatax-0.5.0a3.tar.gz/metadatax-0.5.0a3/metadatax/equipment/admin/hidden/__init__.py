from .maintenance_type import MaintenanceTypeAdmin
from .platform_type import PlatformTypeAdmin
