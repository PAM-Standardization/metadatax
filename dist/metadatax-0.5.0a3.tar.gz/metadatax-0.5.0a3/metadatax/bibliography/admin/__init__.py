from .article import ArticleAdmin
from .software import SoftwareAdmin
from .conference import ConferenceAdmin
from .poster import PosterAdmin
