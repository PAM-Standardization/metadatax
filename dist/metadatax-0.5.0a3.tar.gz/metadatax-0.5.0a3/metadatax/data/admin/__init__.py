from .file_format import FileFormatAdmin

from .audio_file import AudioFileAdmin
from .detection_file import DetectionFileAdmin
