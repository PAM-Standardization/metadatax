from .institution import InstitutionAdmin
from .person import PersonAdmin
from .tag import TagAdmin
from .team import TeamAdmin
