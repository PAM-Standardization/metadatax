from .author import AuthorNode

from .article import ArticleNode
from .software import SoftwareNode
from .conference import ConferenceNode
from .poster import PosterNode
